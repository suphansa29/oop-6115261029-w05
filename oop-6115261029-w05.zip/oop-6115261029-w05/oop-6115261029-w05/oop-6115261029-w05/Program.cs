﻿using System;

namespace oop_6115261029_w05
{
    class Program
    {
        static void Main(string[] args)
        {
            Building b4 = new Building ("6", "Building 4", "111", "222");
            Room r433 = new Room ("423", "Room 423", "2", "2", "computer",b4);
            Subject S = new Subject ("615261029", "ced", "5.1", "1", "1");
            Lecturer nathee = new Lecturer ("kwang", "eiei", "lecturer");
            Section ced1 = new Section ("15", "12.00", "12.01", r433 , S , nathee );
            Console.WriteLine(r433.ToString());
            Console.WriteLine(ced1.ToString());
        }
    }
}
